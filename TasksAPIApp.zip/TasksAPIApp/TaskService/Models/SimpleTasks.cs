﻿using System;
using System.Collections.Generic;

namespace TaskService.Models
{
    public partial class SimpleTasks
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public bool? IsComplete { get; set; }
    }
}
