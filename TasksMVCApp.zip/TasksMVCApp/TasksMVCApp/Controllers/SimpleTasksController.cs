using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TasksMVCApp.Models;

namespace Controllers
{
    public class SimpleTasksController : Controller
    {
        private readonly TasksContext _context;

        public SimpleTasksController(TasksContext context)
        {
            _context = context;
        }

        // GET: SimpleTasks
        public async Task<IActionResult> Index()
        {
            return View(await _context.SimpleTasks.ToListAsync());
        }

        // Hide completed tasks, or display taks with IsComplete = false
        public async Task<IActionResult> Hide()
        {
            return View(await _context.SimpleTasks.Where(e => e.IsComplete == false).ToListAsync());
        }

        // Create a new task
        public IActionResult Create()
        {
            return View();
        }

        // POST: SimpleTasks/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Description,IsComplete")] SimpleTasks simpleTasks)
        {
            if (ModelState.IsValid)
            {
                _context.Add(simpleTasks);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(simpleTasks);
        }

        // Update the description for a task
        public async Task<IActionResult> Update(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var simpleTasks = await _context.SimpleTasks.FindAsync(id);
            if (simpleTasks == null)
            {
                return NotFound();
            }
            return View(simpleTasks);
        }

        // POST: SimpleTasks/Update/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int id, [Bind("Id,Description,IsComplete")] SimpleTasks simpleTasks)
        {
            if (id != simpleTasks.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(simpleTasks);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SimpleTasksExists(simpleTasks.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(simpleTasks);
        }

        // G?	Mark a task as complete
        public async Task<IActionResult> Mark(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var simpleTasks = await _context.SimpleTasks.FindAsync(id);
            if (simpleTasks == null)
            {
                return NotFound();
            }
            return View(simpleTasks);
        }

        // POST: SimpleTasks/Mark/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Mark(int id, [Bind("Id,Description,IsComplete")] SimpleTasks simpleTasks)
        {
            if (id != simpleTasks.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(simpleTasks);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SimpleTasksExists(simpleTasks.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(simpleTasks);
        }

        // ?	Delete a task that was created by mistake or is no longer needed
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var simpleTasks = await _context.SimpleTasks
                .FirstOrDefaultAsync(m => m.Id == id);
            if (simpleTasks == null)
            {
                return NotFound();
            }

            return View(simpleTasks);
        }

        // POST: SimpleTasks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var simpleTasks = await _context.SimpleTasks.FindAsync(id);
            _context.SimpleTasks.Remove(simpleTasks);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SimpleTasksExists(int id)
        {
            return _context.SimpleTasks.Any(e => e.Id == id);
        }

    }
}
